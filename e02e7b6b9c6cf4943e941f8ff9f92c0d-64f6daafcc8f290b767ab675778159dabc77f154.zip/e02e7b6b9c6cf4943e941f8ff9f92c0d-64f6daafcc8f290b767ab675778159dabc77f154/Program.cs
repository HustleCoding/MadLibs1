using System;

namespace MadLibs
{
  class Program
  {
    static void Main(string[] args)
    {
      /*
      This program will help you to laugh much more.
      Author: Dobinciuc Florin
      */
      string title = "Pretty girl";

      Console.WriteLine(title);
      
      Console.WriteLine("Hey! Check it out! The Mad Libs has started. Good luck!");

      // The template for the story:
      Console.Write("Enter a name: ");
      string name = Console.ReadLine();
      
      Console.Write("Enter an adjective: ");
      string adj0 = Console.ReadLine();
      
      Console.Write("Enter another adjective: ");
      string adj1 = Console.ReadLine();

      Console.Write("Enter one more adejective: ");
      string adj2 = Console.ReadLine();

      Console.Write("Enter a verb: ");
      string verb = Console.ReadLine();

      Console.Write("Enter a noun: ");
      string noun1 = Console.ReadLine();

      Console.WriteLine("Enter a second noun: ");
      string noun2 = Console.ReadLine();

      Console.Write("Enter an animal: ");
      string animal = Console.ReadLine();

      Console.Write("Enter a food: ");
      string food = Console.ReadLine();

      Console.Write("Enter a fruit: ");
      string fruit = Console.ReadLine();

      Console.Write("Enter a superhero: ");
      string superHero = Console.ReadLine();

      Console.Write("Enter a country: ");
      string country = Console.ReadLine();

      Console.Write("Enter a dessert: ");
      string dessert = Console.ReadLine();

      Console.Write("Enter a year: ");
      string year = Console.ReadLine();


      string story = $"This morning {name} woke up feeling {adj0}. 'It is going to be a {adj1} day!' Outside, a bunch of {animal}s were protesting to keep {food} in stores. They began to {verb} to the rhythm of the {noun1}, which made all the {fruit}s very {adj2}. Concerned, {name} texted {superHero}, who flew {name} to {country} and dropped {name} in a puddle of frozen {dessert}. {name}woke up in the year {year}, in a world where {noun2}s ruled the world.";

      Console.WriteLine(story);
    }
  }
}
